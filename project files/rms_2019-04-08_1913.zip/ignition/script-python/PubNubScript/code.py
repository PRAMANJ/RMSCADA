from com.pubnub.api import PNConfiguration
from com.pubnub.api import PubNub
from com.pubnub.api.callbacks import PNCallback
from com.pubnub.api.callbacks import SubscribeCallback
from com.pubnub.api.enums import PNStatusCategory
from com.pubnub.api.models.consumer import PNPublishResult
from com.pubnub.api.models.consumer import PNStatus
from com.pubnub.api.models.consumer.pubsub import PNMessageResult
from com.pubnub.api.models.consumer.pubsub import PNPresenceEventResult
from java.util import Arrays
from com.google.gson import JsonElement
from com.google.gson import JsonObject
channelName="command_channel"
pnchannel="map2-channel"
messageJsonObject = JsonObject()
messageJsonObject.addProperty("msg", "hello")
#messageJsonObject = JSONObject()
#messageJsonObject.put("msg", "hello")
print "Message to send: " + messageJsonObject.toString()
isPubNubOn=False
isError=False
isTimerOn=False
time=0
#
class pncallback(PNCallback):
	def onResponse(self,result,status):
		# Check whether request successfully completed or not.
		if (not status.isError()):
		# Message successfully published to specified channel.                    
		# Request processing failed.
			project.PubNubScript.isPubNubOn=True
			#print "call back received on publish "+str(project.PubNubScript.isPubNubOn)
			project.PubNubScript.isError=False
			pass
		else:
		# Handle message publish error. Check 'category' property to find out possible issue
		# because of which request did fail.
		# Request can be resent using: [status retry];
			print "Publish error"
			project.PubNubScript.isPubNubOn=False
			project.PubNubScript.isError=True
			pass
class subscribeCallback(SubscribeCallback):
	def status(self,pubnub,status):
		if (status.getCategory() == PNStatusCategory.PNConnectedCategory):
		# Connect event. You can do stuff like publish, and know you'll get it.
		# Or just use the connected event to confirm you are subscribed for
		# UI / internal notifications, etc
			project.PubNubScript.isPubNubOn=True
			print "PNConnected status received " + str(project.PubNubScript.isPubNubOn)
			pubnub.publish().channel(channelName).message(messageJsonObject).async(pncallback1)#messageJsonObject
		elif (status.getCategory() == PNStatusCategory.PNUnexpectedDisconnectCategory):
		# This event happens when radio / connectivity is lost
			pass
		elif (status.getCategory() == PNStatusCategory.PNReconnectedCategory):
		# Happens as part of our regular operation. This event happens when
		# radio / connectivity is lost, then regained.    
			pass
		elif (status.getCategory() == PNStatusCategory.PNDecryptionErrorCategory):
		# Handle messsage decryption error. Probably client configured to
		# encrypt messages and on live data feed it received plain text.
			pass
	#Override
	def message(self,pubnub, message):
		# Handle new message stored in message.message
		if (message.getChannel() != None):
			# Message has been received on channel group stored in
			# message.getChannel()
			global msg
			project.PubNubScript.msg = message.getMessage().getAsJsonObject().get("msg").getAsString()
			#project.PubNubScript.msg = message.getMessage().getAsString()
			#project.PubNubScript.isPubNubOn=True
			print "msg recd - channel/msg : " + message.getChannel() + "/" +project.PubNubScript.msg
			cmd=project.PubNubScript.msg.strip().split(" ")
			if cmd[0]=="GETTAGS":
				pubnub.publish().channel("response").message(cmd[0]+"^"+project.InitPubNubScript.content[cmd[1]]).async(pncallback1)
				#project.InitPubNubScript.content[cmd[1]]
			elif cmd[0]=="SCAN":
				#print "command received " + msg
				output=project.PubNubDevScript.command(cmd[0],cmd[1])
				#print "output= "+str(output)
				#messageJsonObject3 = JsonObject()
				#messageJsonObject3.addProperty("msg", cmd[0]+"!"+str(output))
				pubnub.publish().channel("response").message(cmd[0]+"^"+output).async(pncallback1)
			#pubnub.removeListener(subscribeCallback1)
		else:
			# Message has been received on channel stored in
			# message.getSubscription()
			global receivedMessageObject
			receivedMessageObject = message.getMessage()
			print "Received message content: " + receivedMessageObject.toString()
			# extract desired parts of the payload, using Gson
			#project.PubNubScript.msg = message.getMessage().getAsJsonObject().get("msg").getAsString()
			project.PubNubScript.msg = message.getMessage().getAsString()
			print "msg content-subscribe: " + message.getChannel() + "/"  + project.PubNubScript.msg
		#        log the following items with your favorite logger
		#            - message.getMessage()
		#            - message.getSubscription()
		#            - message.getTimetoken()
	def presence(self,pubnub, presence):
		pass
def publisheon():
	#import ast
	fname="C:\\RMS\\tags.txt"
	project.PubNubDevScript.command("SCAN",fname)
	messageJsonObject21=[]
	chnames=[]
	del messageJsonObject21[:]
	del chnames[:]
	channels=len(project.InitPubNubScript.eonchannels)
	#print "channels="+ str(channels)
	for ch in project.InitPubNubScript.eonchannels:
		messageJsonObject1 = JsonObject()
		messageJsonObject2 = JsonObject()
		#bf=""
		#print "ch="+str(ch)
		#print "name="+str(ch["name"])
		chnames.append(ch["name"])
		for tg in ch["tags"]:
			#print "tags:"+str(tg)
			tg1=tg.replace("[","<")
			tg1=tg1.replace("]",">")
			v=getval(tg)
			#v1=v.split(',')
			#v11=int(v1[1])
			#if ch["name"][0:5] == "TABLE":
			#	index=project.InitPubNubScript.taglist["C:\\RMS\\tags.txt"].index(tg)
			#	tgprop=project.InitPubNubScript.TAGDB[fname][index]
			#	bf=tg1+"~"
			#	bf+=tgprop["def"]+"~"
			#	bf+=v1[0]+"~"
			#	bf+=v1[1]+"~"
			#	bf+=tgprop["unit"]+"~"
			#	bf+=tgprop["conditions"][v11]["cond"]+"~"
			#	bf+=tgprop["conditions"][v11]["lim"]+"~"
			#	bf+=tgprop["conditions"][v11]["label"]
				#print "messageObj1= "+messageJsonObject1.toString()
			#	messageJsonObject1.addProperty(tg1, bf)
			#else:
			messageJsonObject1.addProperty(tg1, v)
		#print "messageObj1= "+messageJsonObject1.toString()
		messageJsonObject2.add("eon",messageJsonObject1)			
		#print "messageObj2= "+messageJsonObject2.toString(
		messageJsonObject21.append(messageJsonObject2)
		#print "obj3="+messageJsonObject3.toString()
	for i in range(channels):
		pubnub.publish().channel(chnames[i]).message(messageJsonObject21[i]).async(pncallback1)
		#pubnub.publish().channel(chnames[i]).message("'eon':{'[default]Tag 0':50.0,{'[default]Tag 1':21,{'[default]Tag 2': 60,{'[default]Tag 3': 55,{'[default]Tag 4': 73}").async(pncallback1)
		#print chnames[i]+str(messageJsonObject21[i])
def initpubnub():
	print 'calling initpubnub'
	fname="C:\\RMS\\tags.txt"
	project.PubNubDevScript.command("GETTAGS",fname)
	fname="C:\\RMS\\eon.txt"
	import ast
	#project.InitPubNubScript.nop()
	if system.file.fileExists(fname):
		project.InitPubNubScript.eoncontent=system.file.readFileAsString(fname)
		#print project.InitPubNubScript.eoncontent
	else:
		print "eon file not found "+fname
		project.InitPubNubScript.eonchannels="{}"
	project.InitPubNubScript.eonchannels = ast.literal_eval(project.InitPubNubScript.eoncontent)
	#.jsonEncode(project.InitPubNubScript.eoncontent)
	#.ast.literal_eval(project.InitPubNubScript.eoncontent)
	channels=len(project.InitPubNubScript.eonchannels)
	#print "channels="+ str(channels)
	#project.InitPubNubScript.eonjson = ast.literal_eval(project.InitPubNubScript.eon)
	#for e in project.InitPubNubScript.eonjson.eon
	#	e.message.eon.
	global pnConfiguration
	pnConfiguration=PNConfiguration()
	configfile="C:\\RMS\\config.js"
	if system.file.fileExists(configfile):
		pubsubkeys=system.file.readFileAsString(configfile)
		pubsubkeys=pubsubkeys.replace("'","");
		pubsubkeys=pubsubkeys.replace(";","");
		#print pubsubkeys		
		pskey=pubsubkeys.split("\n")
		pkey=pskey[0].split("=")
		skey=pskey[1].split("=")
		publishkey=pkey[1].strip()
		subscribekey=skey[1].strip()
		#print publishkey,subscribekey
	else:
		print "config.js file not found in c:rms folder"
		publishkey="demo"
		subscribekey="demo"
	pnConfiguration.setSubscribeKey(subscribekey)
	pnConfiguration.setPublishKey(publishkey)
	pnConfiguration.setSecure(True)
	print "initializing pubnub"
	global pubnub
	pubnub = PubNub(pnConfiguration)
	global pncallback1
	pncallback1=pncallback()
	global subscribeCallback1
	subscribeCallback1=subscribeCallback()
	pubnub.addListener(subscribeCallback1)
	pubnub.subscribe().channels(Arrays.asList(channelName)).execute()
	#pubnub.subscribe().channels(Arrays.asList(pnchannel)).execute()
def stoppubnub():
	try: pubnub
	except NameError:
		print "NameError"
		pass
	else:
		print "destroy"
		project.PubNubScript.isPubNubOn=False
		project.PubNubScript.pubnub.unsubscribe().channels(Arrays.asList(channelName)).execute();
		project.PubNubScript.pubnub.destroy()
		project.PubNubScript.time=0
def getval(vname):
	index=project.InitPubNubScript.taglist["C:\\RMS\\tags.txt"].index(vname)
	if index < 0:
		return "0"
	else:
		#return str(project.InitPubNubScript.values1[index].value)+','+project.InitPubNubScript.states1[index]
		return project.InitPubNubScript.values1[index].value