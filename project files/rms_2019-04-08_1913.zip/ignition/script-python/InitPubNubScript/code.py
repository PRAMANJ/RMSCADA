content={}
TAGDB={}
taglist={}
eoncontent=""
eonchannels={}
eontags={}
values1={}
#states1={}
def nop():
	pass
	return