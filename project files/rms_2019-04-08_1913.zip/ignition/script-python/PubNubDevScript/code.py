def command(cmd,fname):
#if names[0]=="command" and values[0][0:7]=="GETTAGS":
	if cmd=="GETTAGS":
		#fname = values[0][8:]
		#print "GETTAGS called"
		import ast
		project.InitPubNubScript.nop()
		#project.PubNubScript.nop()
		#print fname
		if system.file.fileExists(fname):
			project.InitPubNubScript.content[fname]=system.file.readFileAsString(fname)
			#print "content="+str(project.InitPubNubScript.content[fname])
		else:
			print "TAGSFILE not found"+fname
			project.InitPubNubScript.content[fname]="{}"
		project.InitPubNubScript.TAGDB[fname] = ast.literal_eval(project.InitPubNubScript.content[fname])
		#json.loads(project.NewScript.content[fname])
		#project.NewScript.taglist=[]
		taglist=[];
		#print "TAGDB="+json.dumps(project.NewScript.TAGDB[fname])
		for tag in project.InitPubNubScript.TAGDB[fname]:
			#print "tag="+json.dumps(tag)
			taglist.append(tag['name'])
		#print "taglist="+str(taglist)
		project.InitPubNubScript.taglist[fname]=taglist
		#project.NewScript.init()
		#print "SCAN "+project.InitPostJsonScript.content[fname]
		return project.InitPubNubScript.content[fname]
		#return {'json':content}
		#tim=0;
	elif cmd=="SCAN":
		#fname = values[0][5:]
		#print project.NewScript.taglist
		#values1 = system.tag.readAll(project.NewScript.taglist)
		#print "calling readAll"
		project.InitPubNubScript.values1 = system.tag.readAll(project.InitPubNubScript.taglist[fname])
		#print "VALUES="+str(values1)
		buffer=""
		#dt1=project.NewScript.taglist[0]
		#dt1="Jan 21 2019"
		#dt2="11:29:01"
		date= system.date.now()
		day=str(date)
		#print day
		dt1=day[4:11]+day[24:28]
		dt2=day[11:20]
		#Fri Feb 01 22:28:37 IST 2019
		for x in range(len(project.InitPubNubScript.TAGDB[fname])):
		#for x in range(len(taglist)):
			index=0
			con=0
			for y in project.InitPubNubScript.TAGDB[fname][x]['conditions']:
			#for y in TAGDB[x]['conditions']: 
				if(project.InitPubNubScript.TAGDB[fname][x]['type']=='f'): 
				#if(TAGDB[x]['type']=='f'):
					if(y['cond']==">" and project.InitPubNubScript.values1[x].value > float(y['lim'])):
						con=index
						#print y['cond'],y['lim']
					if(y['cond']=="<" and project.InitPubNubScript.values1[x].value < float(y['lim'])):
						con=index
						#print y['cond'],y['lim']
				if(project.InitPubNubScript.TAGDB[fname][x]['type']=='i'):
				#if(TAGDB[x]['type']=='i'):
					if(y['cond']==">" and project.InitPubNubScript.values1[x].value > int(y['lim'])):
						con=index
						#print y['cond'],y['lim']
					if(y['cond']=="<" and project.InitPubNubScript.values1[x].value < int(y['lim'])):
						con=index
						#print y['cond'],y['lim']
					if(y['cond']=="=" and project.InitPubNubScript.values1[x].value == int(y['lim'])):
						con=index
				if(project.InitPubNubScript.TAGDB[fname][x]['type']=='s'):
				#if(TAGDB[x]['type']=='s'):
					if(y['cond']=="=" and project.InitPubNubScript.values1[x].value == y['lim']):
						con=index
				if(project.InitPubNubScript.TAGDB[fname][x]['type']=='b'):
				#if(TAGDB[x]['type']=='b'):
					if(y['cond']=="=" and (y['lim'] == 'True' and project.InitPubNubScript.values1[x].value)or (y['lim'] == 'False' and not project.InitPubNubScript.values1[x].value)):
						con=index
						#print y['cond'],y['lim']
				index+=1
			#project.InitPubNubScript.states1[x]=str(con)
			buffer+=str(project.InitPubNubScript.values1[x].value)+","+str(con)+"~"
			#buffer+=str(project.InitPubNubScript.values1[x].value)
		#mm='ALL!admin,RX,0,'+dt1+',0,        ,'+dt2+',0~'+buffer
	#Jan 19 2019,0,01:56:06,15:51:53 
		formattedString='{"value":"'+'ALL!admin,RX,1,'+dt1+',0,0       ,'+dt2+',0~'+buffer+'"}'
		#!admin,RX,0,Jan 21 2019,0,     ,11:29:01,0~user/acc/online,date,cycle_time/license/time/pubnub
		#print "formatted string"+formattedString
		return formattedString #