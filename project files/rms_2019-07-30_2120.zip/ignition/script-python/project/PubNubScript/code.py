from com.pubnub.api import PNConfiguration
from com.pubnub.api import PubNub
from com.pubnub.api.callbacks import PNCallback
from com.pubnub.api.callbacks import SubscribeCallback
from com.pubnub.api.enums import PNStatusCategory
from com.pubnub.api.models.consumer import PNPublishResult
from com.pubnub.api.models.consumer import PNStatus
from com.pubnub.api.models.consumer.pubsub import PNMessageResult
from com.pubnub.api.models.consumer.pubsub import PNPresenceEventResult
from java.util import Arrays
from com.google.gson import JsonElement
from com.google.gson import JsonObject
channelName="command_channel"
pnchannel="map2-channel"
messageJsonObject = JsonObject()
messageJsonObject.addProperty("msg", "hello")
#messageJsonObject = JSONObject()
#messageJsonObject.put("msg", "hello")
print "Message to send: " + messageJsonObject.toString()
system.util.getGlobals()['isPubNubOn']=False
system.util.getGlobals()['isError']=False
system.util.getGlobals()['isTimerOn']=False
system.util.getGlobals()['time']=0
#
class pncallback(PNCallback):
	def onResponse(self,result,status):
		# Check whether request successfully completed or not.
		if (not status.isError()):
		# Message successfully published to specified channel.                    
		# Request processing failed.
			system.util.getGlobals()['isPubNubOn']=True
			#print "call back received on publish "+str(project.PubNubScript.isPubNubOn)
			system.util.getGlobals()['isError']=False
			pass
		else:
		# Handle message publish error. Check 'category' property to find out possible issue
		# because of which request did fail.
		# Request can be resent using: [status retry];
			print "Publish error"
			system.util.getGlobals()['isPubNubOn']=False
			system.util.getGlobals()['isError']=True
			pass
class subscribeCallback(SubscribeCallback):
	def status(self,pubnub,status):
		if (status.getCategory() == PNStatusCategory.PNConnectedCategory):
		# Connect event. You can do stuff like publish, and know you'll get it.
		# Or just use the connected event to confirm you are subscribed for
		# UI / internal notifications, etc
			system.util.getGlobals()['isPubNubOn']=True
			print "PNConnected status received " + str(system.util.getGlobals()['isPubNubOn'])
			pubnub.publish().channel(channelName).message(messageJsonObject).async(system.util.getGlobals()['pncallback1'])#messageJsonObject
		elif (status.getCategory() == PNStatusCategory.PNUnexpectedDisconnectCategory):
		# This event happens when radio / connectivity is lost
			pass
		elif (status.getCategory() == PNStatusCategory.PNReconnectedCategory):
		# Happens as part of our regular operation. This event happens when
		# radio / connectivity is lost, then regained.
			pass
		elif (status.getCategory() == PNStatusCategory.PNDecryptionErrorCategory):
		# Handle messsage decryption error. Probably client configured to
		# encrypt messages and on live data feed it received plain text.
			pass
	#Override
	def message(self,pubnub, m):
		import ast
		# Handle new message stored in message.message
		#print m
		if (m.getChannel() != None):
			# Message has been received on channel group stored in
			# message.getChannel()
			#global msg
			msg = m.getMessage().getAsJsonObject().get("msg").getAsString()
			#project.PubNubScript.msg = message.getMessage().getAsString()
			#project.PubNubScript.isPubNubOn=True
			cmd=msg.strip().split("^")
			if(len(cmd)>1):
				#if(cmd[1] != "SCAN"):
					#print "msg recd - channel/msg : " + m.getChannel() + " " + msg
				if (cmd[1]=="LOGIN"):
					usr=cmd[2]
					prof="XX"
					res="FAILURE"
					prof_des="XX"
					acc="XX"
					for elem in system.util.getGlobals()['users_dict']:
						#print elem['user'],cmd[2],elem['userpassword'],cmd[3]
						if elem['user'] == cmd[2] and elem['userpassword'] == cmd[3]:
							prof=elem['userprofile']
							res="SUCCESS"
							acc="XX"
							#print res
							for elem1 in system.util.getGlobals()['profiles_dict']:
								if elem1['profile'] == prof:
									acc=elem1['profileaccess']
									prof_des=elem1['profiledes']
									#print acc
									break
							break
					formattedstring=cmd[0]+"^"+cmd[1]+"^"+res+"^"+usr+"^"+acc+"^"+prof_des
					#print formattedstring
					pubnub.publish().channel("response").message(formattedstring).async(system.util.getGlobals()['pncallback1'])						
				elif cmd[1]=="GETTAGS":
					#print cmd[0],cmd[1],cmd[2]
					pubnub.publish().channel("response").message(cmd[0]+"^"+cmd[1]+"^"+system.util.getGlobals()['content'][cmd[2]]).async(system.util.getGlobals()['pncallback1'])
					#project.InitPubNubScript.content[cmd[1]]
				elif cmd[1]=="GETPROFILES":
					pubnub.publish().channel("response_channel").message(cmd[0]+"^"+cmd[1]+"^"+system.util.getGlobals()['profiles']).async(system.util.getGlobals()['pncallback1'])
					#print "sending message "+cmd[0]+"^"+system.util.getGlobals()['profiles']
					system.util.getGlobals()['profiles_dict']=ast.literal_eval(system.util.getGlobals()['profiles'])
				elif cmd[1]=="GETUSERS":
					pubnub.publish().channel("response_channel").message(cmd[0]+"^"+cmd[1]+"^"+system.util.getGlobals()['users']).async(system.util.getGlobals()['pncallback1'])
					#print "sending message "+cmd[0]+"^"+system.util.getGlobals()['users']
					system.util.getGlobals()['users_dict']=ast.literal_eval(system.util.getGlobals()['users'])
				elif cmd[1]=="WRITETAGS":
					paths = ast.literal_eval(cmd[2])
					values = ast.literal_eval(cmd[3])
					#print "paths,values",paths,values
					system.tag.writeBlocking(paths, values)
				elif cmd[1]=="SCAN":
					#print "command received " + msgsystem.util.getGlobals()['
					#output=project.PubNubDevScript.scantags(cmd[1],cmd[2],cmd[0],cmd[3],cmd[4])
					output=project.PubNubDevScript.scantags(cmd[0],cmd[2],cmd[3],cmd[4],cmd[5])#uid,fname,user,access
					#print "output= "+str(output)
					pubnub.publish().channel("response").message(cmd[0]+"^"+cmd[1]+"^"+output).async(system.util.getGlobals()['pncallback1'])
				#pubnub.removeListener(subscribeCallback1)
		else:
			# Message has been received on channel stored in
			# message.getSubscription()
			#global receivedMessageObject
			receivedMessageObject = m.getMessage()
			print "Received message content: " + receivedMessageObject.toString()
			# extract desired parts of the payload, using Gson
			#project.PubNubScript.msg = message.getMessage().getAsJsonObject().get("msg").getAsString()
			msg = m.getMessage().getAsString()
			print "msg content-subscribe: " + m.getChannel() + "/"  + msg
		#        log the following items with your favorite logger
		#            - message.getMessage()
		#            - message.getSubscription()
		#            - message.getTimetoken()
	def presence(self,pubnub, presence):
		pass
def publisheon():
	#import ast
	fname="C:\\RMS\\tags.txt"
	project.PubNubDevScript.command("SCAN",fname)
	messageJsonObject21=[]
	chnames=[]
	del messageJsonObject21[:]
	del chnames[:]
	channels=len(system.util.getGlobals()['eonchannels'])
	#print "channels="+ str(channels)
	for ch in system.util.getGlobals()['eonchannels']:
		messageJsonObject1 = JsonObject()
		messageJsonObject2 = JsonObject()
		#print "ch="+str(ch)
		#print "name="+str(ch["name"])
		chnames.append(ch["name"])
		for tg in ch["tags"]:
			#print "tags:"+str(tg)
			tg1=tg.replace("[","<")
			tg1=tg1.replace("]",">")
			v=getval(tg)
			messageJsonObject1.addProperty(tg1, v)
		#print "messageObj1= "+messageJsonObject1.toString()
		messageJsonObject2.add("eon",messageJsonObject1)
		#print "messageObj2= "+messageJsonObject2.toString(
		messageJsonObject21.append(messageJsonObject2)
		#print "obj3="+messageJsonObject3.toString()
	for i in range(channels):
		system.util.getGlobals()['pubnub'].publish().channel(chnames[i]).message(messageJsonObject21[i]).async(system.util.getGlobals()['pncallback1'])
		#print chnames[i]+str(messageJsonObject21[i]) 

def initpubnub():
	system.util.getGlobals()['isPubNubOn']=False
	system.util.getGlobals()['isError']=False
	system.util.getGlobals()['isTimerOn']=False
	system.util.getGlobals()['time']=0
	print 'calling initpubnub'
	project.InitPubNubScript.nop()
	fname="C:\\RMS\\tags.txt"
	project.PubNubDevScript.command("GETTAGS",fname)#read the tags.txt data base file
	fname="C:\\rms\\profiles.txt"
	project.PubNubDevScript.command("GETPROFILES",fname)
	fname="C:\\rms\\users.txt"
	project.PubNubDevScript.command("GETUSERS",fname)
	fname="C:\\rms\\eon.txt"
	import ast
	if system.file.fileExists(fname):
		system.util.getGlobals()['eoncontent']=system.file.readFileAsString(fname)#eon.txt file
		print system.util.getGlobals()['eoncontent']
	else:
		print "eon file not found "+fname
		system.util.getGlobals()['eoncontent']="{}"
	system.util.getGlobals()['eonchannels'] = ast.literal_eval(system.util.getGlobals()['eoncontent'])
	#.jsonEncode(project.InitPubNubScript.eoncontent)
	#.ast.literal_eval(project.InitPubNubScript.eoncontent)
	channels=len(system.util.getGlobals()['eonchannels'])
	#print "channels="+ str(channels)
	#project.InitPubNubScript.eonjson = ast.literal_eval(project.InitPubNubScript.eon)
	#for e in project.InitPubNubScript.eonjson.eon
	#	e.message.eon.
	#global pnConfiguration
	system.util.getGlobals()['pnConfiguration']=PNConfiguration()
	configfile="C:\\RMS\\config.js"
	if system.file.fileExists(configfile):
		pubsubkeys=system.file.readFileAsString(configfile)
		pubsubkeys=pubsubkeys.replace("'","")
		pubsubkeys=pubsubkeys.replace(";","")
		#print pubsubkeys		
		pskey=pubsubkeys.split("\n")
		pkey=pskey[0].split("=")
		skey=pskey[1].split("=")
		publishkey=pkey[1].strip()
		subscribekey=skey[1].strip()
		#print publishkey,subscribekey
	else:
		print "config.js file not found in c:rms folder"
		publishkey="demo"
		subscribekey="demo"
	system.util.getGlobals()['pnConfiguration'].setSubscribeKey(subscribekey)
	system.util.getGlobals()['pnConfiguration'].setPublishKey(publishkey)
	system.util.getGlobals()['pnConfiguration'].setSecure(True)
	print "initializing pubnub"
	system.util.getGlobals()['pubnub'] = PubNub(system.util.getGlobals()['pnConfiguration'])
	#global pncallback1
	system.util.getGlobals()['pncallback1'] = pncallback()
	#global subscribeCallback1
	system.util.getGlobals()['subscribeCallback1'] = subscribeCallback()
	system.util.getGlobals()['pubnub'].addListener(system.util.getGlobals()['subscribeCallback1'])
	system.util.getGlobals()['pubnub'].subscribe().channels(Arrays.asList(channelName)).execute()
	#pubnub.subscribe().channels(Arrays.asList(pnchannel)).execute()
def stoppubnub():
	try: system.util.getGlobals()['pubnub']
	except NameError:
		print "NameError"
		pass
	else:
		print "destroy"
		system.util.getGlobals()['isPubNubOn']=False
		system.util.getGlobals()['pubnub'].unsubscribe().channels(Arrays.asList(channelName)).execute();
		system.util.getGlobals()['pubnub'].destroy()
		system.util.getGlobals()['time']=0
def getval(vname):
	index=system.util.getGlobals()['taglist']["C:\\RMS\\tags.txt"].index(vname)
	#print index,vname,str(system.util.getGlobals()['values1'][index].value)
	if index < 0:
		return "0"
	else:
		#return str(project.InitPubNubScript.values1[index].value)+','+project.InitPubNubScript.states1[index]
		return str(system.util.getGlobals()['values1'][index].value)