def command(cmd,fname):
	import ast
#if names[0]=="command" and values[0][0:7]=="GETTAGS":		
	if cmd=="GETTAGS":
		#fname = values[0][8:]
		#print "GETTAGS called"
		#project.InitPubNubScript.nop()
		#print str(system.util.getGlobals()['content'])
		print str(system.util.getGlobals()['eoncontent']),str(system.util.getGlobals()['eonchannels']),str(system.util.getGlobals()['eontags'])
		if system.file.fileExists(fname):
			system.util.getGlobals()['content'][fname]=system.file.readFileAsString(fname)
			#print "content="+str(project.InitPubNubScript.content[fname])
		else:
			print "TAGSFILE not found"+fname
			system.util.getGlobals()['content'][fname]="{}"
		system.util.getGlobals()['TAGDB'][fname] = ast.literal_eval(system.util.getGlobals()['content'][fname])
		#json.loads(project.NewScript.content[fname])
		#project.NewScript.taglist=[]
		taglist=[]
		#print "TAGDB="+json.dumps(project.NewScript.TAGDB[fname])
		for tag in system.util.getGlobals()['TAGDB'][fname]:
			#print "tag="+json.dumps(tag)
			taglist.append(tag['name'])
		#print "taglist="+str(taglist)
		system.util.getGlobals()['taglist'][fname]=taglist
		#print "SCAN "+project.InitPostJsonScript.content[fname]
		#return system.util.getGlobals()['content'][fname]
		return ""
	elif cmd=="GETUSERS":
		#print "GETUSERS called"
		#print str(system.util.getGlobals()['users']),str(system.util.getGlobals()['usres'])
		if system.file.fileExists(fname):
			system.util.getGlobals()['users']=system.file.readFileAsString(fname)
			#system.util.getGlobals()['users']=system.util.getGlobals()['users'].replace("\n","");
			#system.util.getGlobals()['users']=system.util.getGlobals()['users'].replace("\t","");
		else:
			print "USERSFILE not found "+fname
			system.util.getGlobals()['users']="{}"
		#return system.util.getGlobals()['users']
		print "users= "+system.util.getGlobals()['users']
		system.util.getGlobals()['users_dict']=ast.literal_eval(system.util.getGlobals()['users'])
		return ""
	elif cmd=="GETPROFILES":
		#print "GETPROFILES called"
		if system.file.fileExists(fname):
			system.util.getGlobals()['profiles']=system.file.readFileAsString(fname)
			#system.util.getGlobals()['profiles']=system.util.getGlobals()['profiles'].replace("\n","");
			#system.util.getGlobals()['profiles']=system.util.getGlobals()['profiles'].replace("\t","");
			#print "content="+str(project.InitPubNubScript.content[fname])
		else:
			print "PROFILEFILE not found "+fname
			system.util.getGlobals()['profiles']="{}"		
		system.util.getGlobals()['profiles_dict']=ast.literal_eval(system.util.getGlobals()['profiles'])
		print "profiles= "+system.util.getGlobals()['profiles']
		return ""
	elif cmd=="SCAN":
		system.util.getGlobals()['values1'] = system.tag.readAll(system.util.getGlobals()['taglist'][fname])
		return ""
def scantags(uid,fname,usr,acc,lic):
	if not system.util.getGlobals()['isTimerOn']:
		command("SCAN",fname)
	#print "VALUES="+str(values1)
	buffer=""
	#dt1=project.NewScript.taglist[0]
	#dt1="Jan 21 2019"
	#dt2="11:29:01"
	date= system.date.now()
	day=str(date)
	#print day
	dt1=day[4:11]+day[24:28]
	dt2=day[11:20]
	#Fri Feb 01 22:28:37 IST 2019
	for x in range(len(system.util.getGlobals()['TAGDB'][fname])):
	#for x in range(len(taglist)):
		index=0
		con=0
		for y in system.util.getGlobals()['TAGDB'][fname][x]['conditions']:
		#for y in TAGDB[x]['conditions']: 
			if(system.util.getGlobals()['TAGDB'][fname][x]['type']=='f'): 
			#if(TAGDB[x]['type']=='f'):
				if(y['cond']==">" and system.util.getGlobals()['values1'][x].value > float(y['lim'])):
					con=index
					#print y['cond'],y['lim']
				if(y['cond']=="<" and system.util.getGlobals()['values1'][x].value < float(y['lim'])):
					con=index
					#print y['cond'],y['lim']
			if(system.util.getGlobals()['TAGDB'][fname][x]['type']=='i'):
			#if(TAGDB[x]['type']=='i'):
				if(y['cond']==">" and system.util.getGlobals()['values1'][x].value > int(y['lim'])):
					con=index
					#print y['cond'],y['lim']
				if(y['cond']=="<" and system.util.getGlobals()['values1'][x].value < int(y['lim'])):
					con=index
					#print y['cond'],y['lim']
				if(y['cond']=="=" and system.util.getGlobals()['values1'][x].value == int(y['lim'])):
					con=index
			if(system.util.getGlobals()['TAGDB'][fname][x]['type']=='s'):
			#if(TAGDB[x]['type']=='s'):
				if(y['cond']=="=" and system.util.getGlobals()['values1'][x].value == y['lim']):
					con=index
			if(system.util.getGlobals()['TAGDB'][fname][x]['type']=='b'):
			#if(TAGDB[x]['type']=='b'):
				if(y['cond']=="=" and (y['lim'] == 'True' and system.util.getGlobals()['values1'][x].value)or (y['lim'] == 'False' and not system.util.getGlobals()['values1'][x].value)):
					con=index
					#print y['cond'],y['lim']
			index+=1
		#project.InitPubNubScript.states1[x]=str(con)
		buffer+=str(system.util.getGlobals()['values1'][x].value)+","+str(con)+"~"
		#buffer+=str(system.util.getGlobals()['values1'][x].value)
	#mm='ALL!admin,RX,0,'+dt1+',0,        ,'+dt2+',0~'+buffer
#Jan 19 2019,0,01:56:06,15:51:53 
	formattedString='{"value":"'+uid+'!'+usr+','+acc+',1,'+dt1+',0,       '+lic+','+dt2+',1~'+buffer+'"}'
	#!admin,RX,0,Jan 21 2019,0,     ,11:29:01,0~user/acc/online,date,cycle_time/license/time/pubnub
	#print "formatted string"+formattedString
	return formattedString #